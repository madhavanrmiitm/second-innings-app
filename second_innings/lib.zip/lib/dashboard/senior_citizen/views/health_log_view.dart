import 'package:flutter/material.dart';

class HealthLogView extends StatelessWidget {
  const HealthLogView({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(body: Center(child: Text('Health Log Screen')));
  }
}
