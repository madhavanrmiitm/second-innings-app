import 'package:flutter/material.dart';

class LocalGroupsView extends StatelessWidget {
  const LocalGroupsView({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(body: Center(child: Text('Local Groups Screen')));
  }
}
